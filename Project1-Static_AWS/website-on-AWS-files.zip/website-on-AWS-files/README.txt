Below are the different URL'S used to access the static travel blogging website

1. cloud front Domain name: - https://d1dhzaf7fsvha.cloudfront.net/


2. Website endpoint: - http://my-174823541177-bucket.s3-website-us-east-1.amazonaws.com/


3. S3 object url: - https://my-174823541177-bucket.s3.amazonaws.com/index.html
